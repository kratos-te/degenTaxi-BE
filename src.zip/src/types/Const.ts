export const GAME_COUNT_DOWN = 6500;
