export interface Game {
  id: number
  random: number
  start_at: Date
  end_at: Date
  status: boolean
}
