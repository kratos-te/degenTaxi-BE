export interface Player {
  id: number;
  bet_amount: number;
  game_id: number;
  wallet: string;
  withdraw_amount: number;
  balance_change: number;
}
