// export function logError(scope: string, error: any, locals?: any): string {
//   console.error({
//     scope,
//     error,
//     locals,
//   });
//   return "Failed in " + scope;
// }
